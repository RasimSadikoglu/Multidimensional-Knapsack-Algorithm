Running the program:
g++ -O3 main.cpp -o main
./main <sample.txt> or ./main

*-O3 flag is optimal, it reduces execution time by 65%.

**Program will run until it traverses all the path, pressing CTRL+C will stop the
program running and will save the current results into the output.txt.